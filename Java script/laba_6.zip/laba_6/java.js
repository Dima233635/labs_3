function filterBy(array, dataType) {
    return array.filter(item => typeof item !== dataType);
}

function promptArray(message) {
    const input = prompt(message);
    if (!input) return [];
    return input.split(",").map(item => item.trim());
}

const dataString = promptArray("Введите элементы массива через запятую:");
const dataType = prompt("Введите тип данных, который хотите исключить:");

const filteredData = filterBy(dataString, dataType);
console.log(filteredData);